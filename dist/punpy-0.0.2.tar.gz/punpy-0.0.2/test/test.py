import punpy
import numpy as np
import matplotlib.pyplot as plt
import xarray as xr
import scipy.linalg   # SciPy Linear Algebra Library
import time
from multiprocessing import Pool

    #
    # def surf_temp_calc(CH4,CH5):
    #     return 2* CH4 - CH5
    #
    #
    # def surf_temp_calc_slow(CH4,CH5):
    #     time.sleep(0.1)
    #     return 2* CH4 - CH5

    #
    #
    # prop=punpy.MCPropagation(1000,2)
    #
    # avhrr_fcdr_ds = xr.open_dataset(r'C:\Users\pdv\Downloads\Harmonisation-master\Harmonisation-master\training\workshop_2019\avhrr_sample_easyFCDR.nc')
    #
    # CH4=avhrr_fcdr_ds["Ch4"].values[0:3]
    # CH5=avhrr_fcdr_ds["Ch5"].values[0:3]
    #
    # ur_CH4=avhrr_fcdr_ds.u_independent_Ch4.values[0:3]
    # us_CH4=avhrr_fcdr_ds.u_structured_Ch4.values[0:3]
    # uc_CH4=avhrr_fcdr_ds.u_common_Ch4.values[0:3]
    #
    # ur_CH5=avhrr_fcdr_ds.u_independent_Ch5.values[0:3]
    # us_CH5=avhrr_fcdr_ds.u_structured_Ch5.values[0:3]
    # uc_CH5=avhrr_fcdr_ds.u_common_Ch5.values[0:3]
    #
    #
    #     uf,ucorr=prop.propagate_random(surf_temp_calc_slow,[CH4,CH5],[np.ones(CH4.shape),np.ones(CH5.shape)],return_corr=True,corr_between=np.ones((2,2)))
    #     print(uf,ucorr)
    #
    # uf,ucorr=prop.propagate_both(surf_temp_calc,[CH4,CH5],[np.zeros(CH4.shape),np.zeros(CH5.shape)],[np.ones(CH4.shape),np.ones(CH5.shape)],return_corr=True,corr_between=np.ones((2,2)))
    # print(uf,ucorr)

    #uf,ucorr=prop.propagate_systematic(surf_temp_calc,[CH4,CH5],[np.ones(CH4.shape),np.ones(CH5.shape)],return_corr=True)
    #print(uf,ucorr)

import punpy
import time
import numpy as np


# your measurement function
def calibrate_slow(L0,gains,dark):
    time.sleep(0.1)
    return (L0-dark)*gains


# your data
L0 = np.array([0.43,0.8,0.7,0.65,0.9])
dark = np.array([0.05,0.03,0.04,0.05,0.06])
gains = np.array([23,26,28,29,31])

# your uncertainties
L0_ur = L0*0.05  # 5% random uncertainty
L0_us = np.ones(5)*0.03  # systematic uncertainty of 0.03 (common between bands)
gains_ur = np.array([0.5,0.7,0.6,0.4,0.1])  # random uncertainty
gains_us = np.array([0.1,0.2,0.1,0.4,0.3])  # systematic uncertainty (different for each band but fully correlated)
dark_ur = np.array([0.01,0.002,0.006,0.002,0.015])  # random uncertainty

if __name__ == "__main__":
    prop = punpy.MCPropagation(1000,parallel_cores=4)
    L1 = calibrate_slow(L0,gains,dark)
    t1=time.time()
    L1_ur = prop.propagate_random(calibrate_slow,[L0,gains,dark],[L0_ur,gains_ur,dark_ur])
    t2=time.time()
    L1_us = prop.propagate_systematic(calibrate_slow,[L0,gains,dark],[L0_us,gains_us,np.zeros(5)])
    L1_ut,L1_cov = prop.propagate_both(calibrate_slow,[L0,gains,dark],[L0_ur,gains_ur,dark_ur],[L0_us,gains_us,np.zeros(5)])

    print(L1)
    print(L1_ur)
    print(L1_us)
    print(L1_ut)
    print(L1_cov)
    print("propogate_random took: ",t2-t1," s")
